"""Plugin system for edge-case devices."""
from .base import BasePlugin

__all__ = ["BasePlugin"]
