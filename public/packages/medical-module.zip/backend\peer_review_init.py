"""Peer Review module - Medical professional verification and drug pitch review"""
from .routes import router as peer_review_router

__all__ = ["peer_review_router"]
