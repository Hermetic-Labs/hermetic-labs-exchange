﻿/**
 * Stripe Connector - EVE-OS Marketplace Package
 * @packageDocumentation
 */

// Main connector class
export { StripeConnector, stripeConnector } from './StripeConnector';

// Types
export type {
    StripeConfig,
    PaymentIntentParams,
    PaymentIntent,
    Customer,
    Subscription,
    Invoice,
    Charge,
    WebhookEvent,
    StripeEventType
} from './types';
