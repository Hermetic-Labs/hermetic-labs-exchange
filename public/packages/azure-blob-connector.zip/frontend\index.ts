﻿/**
 * azure-blob-connector - EVE OS Marketplace Package
 *
 * Azure Blob Storage integration with containers, blobs, and SAS tokens.
 */

// Connector
export { AzureBlobConnector } from './AzureBlobConnector';

// Types
export type {
  AzureBlobConfig,
  AzureBlob,
  BlobMetadata,
  ListBlobsOptions,
  ListBlobsResult,
  PutBlobOptions,
  GetBlobResult,
  CopyBlobOptions,
  SASTokenOptions,
  SASTokenResult,
  BlockInfo,
  BlockUploadOptions,
  UploadProgress,
  BlobType,
  AccessTier,
  LeaseState,
  LeaseStatus,
  AzureBlobConnectorEvents,
  AzureBlobError,
} from './types';

export { AzureBlobConnectorError } from './types';

// Utilities
export { EventEmitter } from './EventEmitter';
export { default as crypto } from '../../_shared/crypto';
