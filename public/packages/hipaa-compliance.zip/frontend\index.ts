/**
 * HIPAA Privacy Suite - EVE OS Marketplace Package
 * @packageDocumentation
 */

// Main service class
export * from './HIPAAPrivacyService';

// Types
export type {
    HIPAAConfig,
    PHICategory,
    AccessPurpose,
    BreachSeverity,
    PHIDetectionParams,
    PHIEntity,
    PHIDetectionResult,
    PHIMaskParams,
    PHIMaskResult,
    AccessValidationParams,
    AccessValidationResult,
    AuditLogEntry,
    AuditLogResult,
    BreachReportParams,
    BreachReportResult,
    HIPAAEventMap
} from './types';
