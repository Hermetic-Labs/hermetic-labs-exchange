/**
 * VRMCompanion - Main component for the VRM Companion module
 * 
 * Features:
 * - 3D VRM avatar rendering with Three.js
 * - Lip sync driven by phoneme timeline or audio amplitude
 * - Configurable controls for smoothing, gain, and mouth limits
 * - Mic input support for real-time lip sync
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js';
import { VRMLoaderPlugin, VRM } from '@pixiv/three-vrm';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import LipSyncService, { VisemeKey } from './LipSyncService';
import { onStateChange as onTTSStateChange, getAudioElement, getAnalyser } from '@/services/ttsService';

const DEFAULT_VRM_URL = 'https://cdn.jsdelivr.net/gh/pixiv/three-vrm@dev/packages/three-vrm/examples/models/VRM1_Constraint_Twist_Sample.vrm';



interface VRMCompanionProps {
    /** Custom model URL (VRM, GLB, or FBX) */
    modelUrl?: string;
    /** @deprecated Use modelUrl instead */
    vrmUrl?: string;
    /** Reference to external audio element for TTS integration */
    ttsAudioRef?: React.RefObject<HTMLAudioElement>;
    /** Callback when avatar speaks */
    onSpeakRequest?: (text: string) => void;
    /** Container className */
    className?: string;
}

export const VRMCompanion: React.FC<VRMCompanionProps> = ({
    modelUrl,
    vrmUrl,
    ttsAudioRef,
    onSpeakRequest,
    className = '',
}) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const controlsRef = useRef<OrbitControls | null>(null);
    const vrmRef = useRef<VRM | null>(null);
    const fbxModelRef = useRef<THREE.Group | null>(null);
    const mixerRef = useRef<THREE.AnimationMixer | null>(null);
    const lipSyncRef = useRef<LipSyncService | null>(null);
    const clockRef = useRef<THREE.Clock>(new THREE.Clock());

    const [availableModels, setAvailableModels] = useState<{ name: string; url: string }[]>([]);
    const [selectedModelUrl, setSelectedModelUrl] = useState(modelUrl || '');
    const activeModelUrl = vrmUrl || selectedModelUrl;
    const [modelLoaded, setModelLoaded] = useState(false);
    // Keep vrmLoaded for backward compatibility
    const vrmLoaded = modelLoaded;
    const [status, setStatus] = useState<string>('Initializing...');
    const [phonemeError, setPhonemeError] = useState<string | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isMicActive, setIsMicActive] = useState(false);
    const [isTesting, setIsTesting] = useState(false);
    const [amplitudeMode, setAmplitudeMode] = useState(false);
    const [physicsEnabled, setPhysicsEnabled] = useState(false);
    const [smoothing, setSmoothing] = useState(0.3);
    const [gain, setGain] = useState(2.0);
    const [maxMouthOpen, setMaxMouthOpen] = useState(0.8);
    const [visemeWeights, setVisemeWeights] = useState<Record<VisemeKey, number>>({
        aa: 0, ih: 0, ou: 0, ee: 0, oh: 0
    });
    const [availableExpressions, setAvailableExpressions] = useState<string[]>([]);
    const [availableAnimations, setAvailableAnimations] = useState<string[]>([]);
    const [currentAnimationIndex, setCurrentAnimationIndex] = useState<number>(-1);
    const [meshList, setMeshList] = useState<{ name: string; mesh: THREE.Mesh; visible: boolean }[]>([]);

    // Fetch available models from backend on mount
    useEffect(() => {
        const fetchModels = async () => {
            try {
                const response = await fetch('/marketplace/modules/vrm-companion/models');
                const models = await response.json();
                setAvailableModels(models);
                // Set first model as default if no model URL provided
                if (models.length > 0 && !selectedModelUrl) {
                    setSelectedModelUrl(models[0].url);
                }
            } catch (error) {
                console.error('[VRMCompanion] Failed to fetch models:', error);
                setAvailableModels([]);
            }
        };
        fetchModels();
    }, []);

    // Initialize Three.js scene
    useEffect(() => {
        if (!containerRef.current) return;

        const container = containerRef.current;

        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x0a0a12);
        sceneRef.current = scene;

        // Use fallback size if container not sized yet
        const width = container.clientWidth || window.innerWidth * 0.7;
        const height = container.clientHeight || window.innerHeight;

        const camera = new THREE.PerspectiveCamera(
            35,
            width / height,
            0.1,
            100
        );
        camera.position.set(0, 1.5, 1.5);  // Closer, face level
        cameraRef.current = camera;

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        renderer.setSize(width, height);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        // Ensure canvas fills container
        renderer.domElement.style.display = 'block';
        renderer.domElement.style.width = '100%';
        renderer.domElement.style.height = '100%';

        container.appendChild(renderer.domElement);
        rendererRef.current = renderer;

        const controls = new OrbitControls(camera, renderer.domElement);
        controls.target.set(0, 1.4, 0);  // Look at face level
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.update();
        controlsRef.current = controls;

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(1, 2, 1);
        scene.add(directionalLight);

        // Grid
        const gridHelper = new THREE.GridHelper(10, 10, 0x00ff99, 0x003322);
        gridHelper.position.y = 0;
        scene.add(gridHelper);

        // Initialize LipSync service
        lipSyncRef.current = new LipSyncService({ smoothing, gain, maxMouthOpen });

        // Animation loop
        const animate = () => {
            const dt = clockRef.current.getDelta();

            // Update lip sync for both VRM and FBX models
            if (lipSyncRef.current && (vrmRef.current || fbxModelRef.current)) {
                lipSyncRef.current.update(dt);
                const weights = lipSyncRef.current.currentWeights;
                // Debug: Log non-zero weights
                const nonZero = Object.entries(weights).filter(([_, v]) => v > 0.01);
                if (nonZero.length > 0) {
                    console.log('[VRMCompanion] Non-zero weights:', nonZero);
                }
                setVisemeWeights(weights);
            }

            // Update VRM with physics optionally disabled
            if (vrmRef.current) {
                if (physicsEnabled) {
                    vrmRef.current.update(dt);
                } else {
                    // Update VRM without physics (skip spring bone simulation)
                    vrmRef.current.expressionManager?.update();
                    vrmRef.current.lookAt?.update(dt);
                    vrmRef.current.humanoid?.update();
                }
            }

            // Update FBX animation mixer if present
            if (mixerRef.current) {
                mixerRef.current.update(dt);
            }

            controlsRef.current?.update();
            renderer.render(scene, camera);
        };

        renderer.setAnimationLoop(animate);

        // Handle resize
        const handleResize = () => {
            if (!container || !camera || !renderer) return;
            const w = container.clientWidth || window.innerWidth * 0.7;
            const h = container.clientHeight || window.innerHeight;
            camera.aspect = w / h;
            camera.updateProjectionMatrix();
            renderer.setSize(w, h);
        };
        window.addEventListener('resize', handleResize);

        // Auto-load model
        loadModel();

        return () => {
            window.removeEventListener('resize', handleResize);
            renderer.setAnimationLoop(null); // Stop animation loop
            renderer.dispose();
            controlsRef.current?.dispose();
            if (container && renderer.domElement) {
                container.removeChild(renderer.domElement);
            }
            lipSyncRef.current?.dispose();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Update config when sliders change
    useEffect(() => {
        lipSyncRef.current?.updateConfig({ smoothing, gain, maxMouthOpen });
    }, [smoothing, gain, maxMouthOpen]);

    // Track amplitude mode
    useEffect(() => {
        if (lipSyncRef.current) {
            lipSyncRef.current.forceAmplitudeMode = amplitudeMode;
        }
    }, [amplitudeMode]);

    // Connect lip sync to Global Chat TTS (shared ttsService)
    useEffect(() => {
        console.log('[VRMCompanion] Setting up TTS state listener, vrmLoaded:', vrmLoaded);

        const unsubscribe = onTTSStateChange(async (state) => {
            console.log('[VRMCompanion] TTS state changed:', state, 'vrmLoaded:', vrmLoaded, 'lipSyncRef:', !!lipSyncRef.current);

            if (state.playing && lipSyncRef.current && vrmLoaded) {
                const audio = getAudioElement();
                const analyser = getAnalyser();
                console.log('[VRMCompanion] TTS playing, audio:', !!audio, 'analyser:', !!analyser);

                if (audio) {
                    try {
                        // Fetch phonemes if text is available and not in amplitude-only mode
                        if (state.text && !amplitudeMode) {
                            try {
                                console.log('[VRMCompanion] Fetching phonemes for:', state.text.substring(0, 50) + '...');
                                const { api } = await import('@/services/api');
                                const phonemeData = await api.textToPhonemes(state.text);

                                // Only process if we got actual phoneme data (not empty)
                                if (phonemeData.phonemes && phonemeData.phonemes.trim()) {
                                    // Parse phoneme string into timeline
                                    const phonemes = phonemeData.phonemes.split(' ').filter(p => p.trim());

                                    if (phonemes.length > 0 && audio.duration > 0) {
                                        const avgDuration = audio.duration / phonemes.length;

                                        const timeline = phonemes.map((phoneme, i) => ({
                                            t0: i * avgDuration,
                                            t1: (i + 1) * avgDuration,
                                            phoneme: phoneme
                                        }));

                                        console.log(`[VRMCompanion] Created phoneme timeline:`, {
                                            phonemeCount: timeline.length,
                                            audioDuration: audio.duration.toFixed(2),
                                            avgDuration: avgDuration.toFixed(3),
                                            firstPhoneme: timeline[0],
                                            lastPhoneme: timeline[timeline.length - 1]
                                        });
                                        lipSyncRef.current.ingestPhonemeTimeline(timeline);
                                        console.log('[VRMCompanion] Timeline ingested successfully');
                                    } else {
                                        console.warn('[VRMCompanion] Invalid timeline data:', {
                                            phonemeCount: phonemes.length,
                                            duration: audio.duration
                                        });
                                    }
                                } else {
                                    // Phonemizer returned empty - log error but continue with amplitude
                                    console.warn('[VRMCompanion] Phonemizer returned no data, using amplitude mode');
                                    setPhonemeError('Phonemizer unavailable - using amplitude mode');
                                }
                            } catch (phonemeErr) {
                                // Phoneme fetch failed - log error but continue with amplitude
                                console.warn('[VRMCompanion] Phoneme fetch failed, using amplitude fallback:', phonemeErr);
                                setPhonemeError(`Phoneme error: ${phonemeErr} - using amplitude mode`);
                            }
                        }

                        // Pass the shared ttsService analyser to avoid duplicate audio connections
                        console.log('[VRMCompanion] Connecting to audio:', {
                            hasAudio: !!audio,
                            hasExternalAnalyser: !!analyser,
                            audioDuration: audio?.duration,
                            audioReadyState: audio?.readyState
                        });
                        await lipSyncRef.current.connectToAudio(audio, analyser ?? undefined);
                        setIsPlaying(true);
                        setStatus(amplitudeMode ? 'Lip syncing (amplitude)...' : 'Lip syncing (phonemes)...');
                        console.log('[VRMCompanion] ✅ Connected to audio successfully');
                        console.log('[VRMCompanion] LipSync state:', {
                            hasTimeline: lipSyncRef.current.currentWeights !== undefined,
                            amplitudeOnly: (lipSyncRef.current as any).amplitudeOnly,
                            forceAmplitudeMode: (lipSyncRef.current as any).forceAmplitudeMode
                        });
                    } catch (err) {
                        console.warn('[VRMCompanion] Failed to connect lip sync:', err);
                    }
                } else {
                    console.warn('[VRMCompanion] No audio element from ttsService');
                }
            } else if (!state.playing && isPlaying) {
                setIsPlaying(false);
                setStatus('Ready');
            }
        });

        return unsubscribe;
    }, [vrmLoaded, isPlaying, amplitudeMode]);

    // Detect model type from URL
    const getModelType = (url: string): 'vrm' | 'fbx' | 'glb' => {
        const lower = url.toLowerCase();
        if (lower.endsWith('.fbx')) return 'fbx';
        if (lower.endsWith('.glb') || lower.endsWith('.gltf')) return 'glb';
        return 'vrm';
    };

    // Load model (VRM, GLB, or FBX)
    const loadModel = useCallback(async () => {
        if (!sceneRef.current) return;

        const type = getModelType(activeModelUrl);
        setStatus(`Loading ${type.toUpperCase()} model...`);

        // Clear existing models
        if (vrmRef.current) {
            sceneRef.current.remove(vrmRef.current.scene);
            vrmRef.current = null;
        }
        if (fbxModelRef.current) {
            sceneRef.current.remove(fbxModelRef.current);
            fbxModelRef.current = null;
        }
        if (mixerRef.current) {
            mixerRef.current.stopAllAction();
            mixerRef.current = null;
        }
        setModelLoaded(false);
        setAvailableExpressions([]);

        try {
            if (type === 'fbx') {
                // Load FBX
                const loader = new FBXLoader();
                const fbx = await loader.loadAsync(activeModelUrl);

                // FBX models from Character Creator are often huge, scale down
                const box = new THREE.Box3().setFromObject(fbx);
                const size = box.getSize(new THREE.Vector3());
                const maxDim = Math.max(size.x, size.y, size.z);
                const targetHeight = 1.8; // 1.8 meters tall
                const scale = targetHeight / maxDim;
                fbx.scale.setScalar(scale);

                // Center and ground the model
                box.setFromObject(fbx);
                const center = box.getCenter(new THREE.Vector3());
                fbx.position.x = -center.x;
                fbx.position.z = -center.z;
                fbx.position.y = -box.min.y;

                sceneRef.current.add(fbx);
                fbxModelRef.current = fbx;

                // Set up animation mixer if model has animations
                if (fbx.animations && fbx.animations.length > 0) {
                    const mixer = new THREE.AnimationMixer(fbx);
                    mixerRef.current = mixer;

                    // Store available animations but don't auto-play (prevents pose fighting)
                    const animNames = fbx.animations.map(a => a.name || `Animation ${fbx.animations.indexOf(a)}`);
                    setAvailableAnimations(animNames);
                    setCurrentAnimationIndex(-1); // No animation playing

                    console.log('[VRMCompanion] FBX animations:', animNames);
                    setStatus(`FBX loaded. ${fbx.animations.length} animation(s) found. Select one to play.`);
                } else {
                    setAvailableAnimations([]);
                    setCurrentAnimationIndex(-1);
                    setStatus('FBX loaded (no animations).');
                }

                // Log bone structure for Character Creator models
                const bones: string[] = [];
                fbx.traverse((child) => {
                    if ((child as THREE.Bone).isBone) {
                        bones.push(child.name);
                    }
                });
                console.log('[VRMCompanion] FBX bones:', bones);

                // Check for morph targets (blend shapes)
                const morphTargets: string[] = [];
                const meshes: { name: string; visible: boolean }[] = [];
                const meshRefs: { name: string; mesh: THREE.Mesh; visible: boolean }[] = [];

                fbx.traverse((child) => {
                    const mesh = child as THREE.Mesh;
                    if (mesh.isMesh && mesh.morphTargetDictionary) {
                        Object.keys(mesh.morphTargetDictionary).forEach(name => {
                            if (!morphTargets.includes(name)) morphTargets.push(name);
                        });
                    }

                    // Log all meshes
                    if (mesh.isMesh) {
                        meshes.push({ name: mesh.name, visible: mesh.visible });

                        // Auto-hide common duplicate mesh patterns
                        const lowerName = mesh.name.toLowerCase();

                        // Hide LOD meshes (keep LOD0, hide LOD1, LOD2, etc.)
                        if (lowerName.includes('_lod') && !lowerName.includes('_lod0')) {
                            mesh.visible = false;
                            console.log(`[VRMCompanion] Hiding LOD mesh: ${mesh.name}`);
                        }

                        // Hide duplicate/backup meshes
                        if (lowerName.includes('_duplicate') || lowerName.includes('_backup') || lowerName.includes('_orig')) {
                            mesh.visible = false;
                            console.log(`[VRMCompanion] Hiding duplicate mesh: ${mesh.name}`);
                        }

                        // Character Creator specific: hide .Shape meshes if main mesh exists
                        if (lowerName.endsWith('.shape') || lowerName.includes('_shape_')) {
                            mesh.visible = false;
                            console.log(`[VRMCompanion] Hiding shape mesh: ${mesh.name}`);
                        }

                        // Hide numbered duplicates (Blender/CC style: .001, .002, _001, _002)
                        if (/\.(00[1-9]|0[1-9]\d|\d{3,})$/.test(mesh.name) || /_00[1-9]$/.test(mesh.name)) {
                            mesh.visible = false;
                            console.log(`[VRMCompanion] Hiding numbered duplicate: ${mesh.name}`);
                        }

                        // Hide symmetry duplicates (.R, .L, _R, _L at the end - common in CC)
                        if (/\.[RL]$/i.test(mesh.name) || /_[RL]$/i.test(mesh.name)) {
                            mesh.visible = false;
                            console.log(`[VRMCompanion] Hiding symmetry mesh: ${mesh.name}`);
                        }

                        // Hide CC-specific duplicate patterns
                        if (lowerName.includes('_copy') || lowerName.includes('copy_') || lowerName.endsWith('_old')) {
                            mesh.visible = false;
                            console.log(`[VRMCompanion] Hiding copy mesh: ${mesh.name}`);
                        }

                        // Store mesh reference for UI controls
                        meshRefs.push({ name: mesh.name, mesh, visible: mesh.visible });
                    }
                });

                console.log('[VRMCompanion] FBX meshes:', meshes);
                setMeshList(meshRefs);

                if (morphTargets.length > 0) {
                    console.log('[VRMCompanion] FBX morph targets:', morphTargets);
                    setAvailableExpressions(morphTargets);
                    setStatus(`FBX loaded. ${morphTargets.length} blend shapes found.`);
                }

                // Connect FBX model to lip sync service
                lipSyncRef.current?.connectToFBX(fbx);

                setModelLoaded(true);

            } else {
                // Load VRM or GLB
                const loader = new GLTFLoader();
                loader.register((parser) => new VRMLoaderPlugin(parser));

                const gltf = await loader.loadAsync(activeModelUrl);
                const vrm = gltf.userData.vrm as VRM;

                if (vrm) {
                    // VRM model
                    vrm.scene.rotation.y = 0;
                    vrm.scene.position.set(0, 0, 0);
                    sceneRef.current.add(vrm.scene);
                    vrmRef.current = vrm;

                    // Analyze expressions
                    if (vrm.expressionManager) {
                        const expressions = vrm.expressionManager.expressions || [];
                        const expNames = expressions.map(
                            (e: { expressionName?: string; name?: string }) => e.expressionName || e.name
                        ).filter(Boolean) as string[];

                        setAvailableExpressions(expNames);
                        console.log('[VRMCompanion] VRM expressions:', expNames);

                        // Check for standard visemes (aa, ee, ih, oh, ou)
                        const visemes = ['aa', 'ee', 'ih', 'oh', 'ou'];
                        const foundVisemes = visemes.filter(v => expNames.includes(v));

                        const mouthRelated = expNames.filter(name =>
                            /mouth|mth|lip|jaw|smile|frown|open|close|vowel|viseme/i.test(name) ||
                            /^[AIUEO]$/i.test(name) ||
                            visemes.includes(name.toLowerCase())
                        );

                        console.log('[VRMCompanion] Viseme detection:', {
                            foundVisemes,
                            mouthRelated,
                            total: expNames.length
                        });

                        if (foundVisemes.length === 0) {
                            setStatus(`⚠️ No visemes (aa/ee/ih/oh/ou)! Found ${mouthRelated.length} mouth expressions.`);
                        } else {
                            setStatus(`Ready. Found ${foundVisemes.length}/5 visemes, ${mouthRelated.length} mouth expressions.`);
                        }
                    } else {
                        console.error('[VRMCompanion] No expression manager found on VRM');
                        setStatus('⚠️ No expression manager found.');
                    }

                    console.log('[VRMCompanion] Connecting VRM to LipSyncService...');
                    lipSyncRef.current?.connectToAvatar(vrm);
                    console.log('[VRMCompanion] VRM connected to LipSyncService');
                } else {
                    // Plain GLB without VRM data
                    const model = gltf.scene;

                    // Scale and position
                    const box = new THREE.Box3().setFromObject(model);
                    const size = box.getSize(new THREE.Vector3());
                    const maxDim = Math.max(size.x, size.y, size.z);
                    if (maxDim > 3) {
                        const scale = 1.8 / maxDim;
                        model.scale.setScalar(scale);
                    }

                    box.setFromObject(model);
                    const center = box.getCenter(new THREE.Vector3());
                    model.position.x = -center.x;
                    model.position.z = -center.z;
                    model.position.y = -box.min.y;

                    sceneRef.current.add(model);
                    fbxModelRef.current = model;

                    // Animations
                    if (gltf.animations && gltf.animations.length > 0) {
                        const mixer = new THREE.AnimationMixer(model);
                        mixerRef.current = mixer;

                        const animNames = gltf.animations.map(a => a.name || `Animation ${gltf.animations.indexOf(a)}`);
                        setAvailableAnimations(animNames);
                        setCurrentAnimationIndex(-1); // Don't auto-play

                        setStatus(`GLB loaded. ${gltf.animations.length} animation(s). Select one to play.`);
                    } else {
                        setAvailableAnimations([]);
                        setCurrentAnimationIndex(-1);
                        setStatus('GLB loaded.');
                    }

                    // Connect GLB model to lip sync service (for morph targets)
                    lipSyncRef.current?.connectToFBX(model);
                }

                setModelLoaded(true);
            }
        } catch (error) {
            console.error('[VRMCompanion] Failed to load model:', error);
            setStatus(`Failed to load ${type.toUpperCase()} model.`);
        }
    }, [activeModelUrl]);

    // Keep loadVRM as alias for backward compatibility
    const loadVRM = loadModel;

    // Play TTS demo - uses shared ttsService (triggers lip sync via useEffect listener)
    const playTTS = useCallback(async () => {
        if (!vrmLoaded) {
            setStatus('Load VRM first');
            return;
        }

        setStatus('Speaking...');

        // Import speak dynamically to avoid circular deps (already imported at top for types)
        const { speak } = await import('@/services/ttsService');
        await speak('Hello world, this is a lip sync test.');

        if (onSpeakRequest) {
            onSpeakRequest('Hello world, this is a lip sync test.');
        }
    }, [vrmLoaded, onSpeakRequest]);

    // Toggle microphone
    const toggleMic = useCallback(async () => {
        if (!vrmLoaded || !lipSyncRef.current) {
            setStatus('Load VRM first');
            return;
        }

        if (isMicActive) {
            lipSyncRef.current.disconnectMic();
            setIsMicActive(false);
            setStatus('Mic disabled');
        } else {
            try {
                await lipSyncRef.current.connectToMic();
                setIsMicActive(true);
                setStatus('Mic active - speak to see lip sync');
            } catch (error) {
                console.error('[VRMCompanion] Mic access failed:', error);
                setStatus('Mic access denied');
            }
        }
    }, [vrmLoaded, isMicActive]);

    // Test blendshapes/morph targets by cycling through them
    const testExpressions = useCallback(async () => {
        if (!modelLoaded) {
            setStatus('Load a model first');
            return;
        }

        setIsTesting(true);

        // Check if VRM model with expression manager
        if (vrmRef.current?.expressionManager) {
            const expressionManager = vrmRef.current.expressionManager;

            // Get all available expressions from the VRM
            const availableExpressions = expressionManager.expressions?.map(
                (e: { expressionName?: string; name?: string }) => e.expressionName || e.name
            ).filter(Boolean) || [];

            console.log('='.repeat(50));
            console.log('[VRMCompanion] ALL AVAILABLE VRM EXPRESSIONS:');
            availableExpressions.forEach((expr: string, i: number) => console.log(`  ${i + 1}. "${expr}"`));
            console.log('='.repeat(50));

            setStatus(`Found ${availableExpressions.length} expressions - check console!`);
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Standard VRM 1.0 visemes
            const standardVisemes: VisemeKey[] = ['aa', 'ih', 'ou', 'ee', 'oh'];

            // VRoid Studio / VRM 0.x style names (mouth shapes)
            const vroidMouthShapes = [
                'A', 'I', 'U', 'E', 'O',           // Japanese vowel visemes (VRoid)
                'Fcl_MTH_A', 'Fcl_MTH_I', 'Fcl_MTH_U', 'Fcl_MTH_E', 'Fcl_MTH_O', // VRoid prefixed
                'vrc.v_aa', 'vrc.v_ih', 'vrc.v_ou', 'vrc.v_ee', 'vrc.v_oh',     // VRChat style
                'Vowel_A', 'Vowel_I', 'Vowel_U', 'Vowel_E', 'Vowel_O',          // Alternative
                'MTH_A', 'MTH_I', 'MTH_U', 'MTH_E', 'MTH_O',                    // Short prefix
            ];

            // Common emotion expressions
            const emotionExpressions = [
                'happy', 'sad', 'angry', 'surprised', 'relaxed', 'neutral',
                'Fcl_ALL_Joy', 'Fcl_ALL_Angry', 'Fcl_ALL_Sorrow', 'Fcl_ALL_Fun',
                'Joy', 'Angry', 'Sorrow', 'Fun'
            ];

            // Blink expressions
            const blinkExpressions = [
                'blink', 'blinkLeft', 'blinkRight',
                'Fcl_EYE_Close', 'Fcl_EYE_Close_L', 'Fcl_EYE_Close_R',
                'Blink', 'Blink_L', 'Blink_R'
            ];

            // Test standard visemes first
            setStatus('Testing standard visemes (aa, ih, ou, ee, oh)...');
            for (const viseme of standardVisemes) {
                const found = availableExpressions.includes(viseme);
                setStatus(`Testing: ${viseme} ${found ? '✓' : '✗ not found'}`);

                if (found) {
                    standardVisemes.forEach(v => expressionManager.setValue(v, 0));
                    expressionManager.setValue(viseme, 1.0);
                    expressionManager.update();

                    const weights: Record<VisemeKey, number> = { aa: 0, ih: 0, ou: 0, ee: 0, oh: 0 };
                    weights[viseme] = 1.0;
                    setVisemeWeights(weights);
                }

                await new Promise(resolve => setTimeout(resolve, 600));
            }

            // Reset
            standardVisemes.forEach(v => {
                try { expressionManager.setValue(v, 0); } catch { /* skip */ }
            });
            setVisemeWeights({ aa: 0, ih: 0, ou: 0, ee: 0, oh: 0 });

            // Test VRoid mouth shapes
            setStatus('Testing VRoid mouth shapes...');
            for (const shape of vroidMouthShapes) {
                if (availableExpressions.includes(shape)) {
                    setStatus(`Testing: ${shape} ✓`);
                    expressionManager.setValue(shape, 1.0);
                    expressionManager.update();
                    await new Promise(resolve => setTimeout(resolve, 500));
                    expressionManager.setValue(shape, 0);
                    expressionManager.update();
                }
            }

            // Test emotions
            setStatus('Testing emotions...');
            for (const expr of emotionExpressions) {
                if (availableExpressions.includes(expr)) {
                    setStatus(`Testing: ${expr} ✓`);
                    expressionManager.setValue(expr, 1.0);
                    expressionManager.update();
                    await new Promise(resolve => setTimeout(resolve, 400));
                    expressionManager.setValue(expr, 0);
                    expressionManager.update();
                }
            }

            // Test blinks
            setStatus('Testing blinks...');
            for (const expr of blinkExpressions) {
                if (availableExpressions.includes(expr)) {
                    setStatus(`Testing: ${expr} ✓`);
                    expressionManager.setValue(expr, 1.0);
                    expressionManager.update();
                    await new Promise(resolve => setTimeout(resolve, 300));
                    expressionManager.setValue(expr, 0);
                    expressionManager.update();
                }
            }

            // Final summary
            const foundVisemes = standardVisemes.filter(v => availableExpressions.includes(v));
            const foundVroid = vroidMouthShapes.filter(v => availableExpressions.includes(v));

            console.log('[VRMCompanion] Standard visemes found:', foundVisemes);
            console.log('[VRMCompanion] VRoid shapes found:', foundVroid);

            // Now test ALL expressions one by one to see which moves the mouth
            setStatus('Testing ALL expressions - watch the mouth!');
            await new Promise(resolve => setTimeout(resolve, 1000));

            for (const expr of availableExpressions as string[]) {
                setStatus(`Testing: "${expr}"`);
                console.log(`[VRMCompanion] Testing expression: "${expr}"`);
                try {
                    expressionManager.setValue(expr, 1.0);
                    expressionManager.update();
                    await new Promise(resolve => setTimeout(resolve, 600));
                    expressionManager.setValue(expr, 0);
                    expressionManager.update();
                    await new Promise(resolve => setTimeout(resolve, 200));
                } catch (e) {
                    console.warn(`[VRMCompanion] Failed to test "${expr}":`, e);
                }
            }

            if (foundVisemes.length === 0 && foundVroid.length === 0) {
                setStatus('⚠️ No standard mouth expressions - check which moved!');
            } else {
                setStatus(`Done! Found: ${foundVisemes.length} visemes, ${foundVroid.length} VRoid shapes`);
            }

        } else if (fbxModelRef.current) {
            // FBX model - test morph targets
            console.log('='.repeat(50));
            console.log('[VRMCompanion] TESTING FBX MORPH TARGETS');
            console.log('='.repeat(50));

            // Find all meshes with morph targets
            const meshesWithMorphs: { mesh: THREE.Mesh; morphs: string[] }[] = [];
            fbxModelRef.current.traverse((child) => {
                const mesh = child as THREE.Mesh;
                if (mesh.isMesh && mesh.morphTargetDictionary && mesh.morphTargetInfluences) {
                    const morphNames = Object.keys(mesh.morphTargetDictionary);
                    if (morphNames.length > 0) {
                        meshesWithMorphs.push({ mesh, morphs: morphNames });
                        console.log(`[VRMCompanion] Mesh "${mesh.name}" has ${morphNames.length} morph targets:`, morphNames);
                    }
                }
            });

            if (meshesWithMorphs.length === 0) {
                setStatus('⚠️ No morph targets found on FBX model');
                setIsTesting(false);
                return;
            }

            setStatus(`Found ${meshesWithMorphs.length} mesh(es) with morph targets`);
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Common Character Creator / ARKit blend shape patterns
            const ccMouthShapes = [
                // ARKit standard (52 blend shapes)
                'jawOpen', 'jawForward', 'jawLeft', 'jawRight',
                'mouthClose', 'mouthFunnel', 'mouthPucker', 'mouthLeft', 'mouthRight',
                'mouthSmileLeft', 'mouthSmileRight', 'mouthFrownLeft', 'mouthFrownRight',
                'mouthDimpleLeft', 'mouthDimpleRight', 'mouthStretchLeft', 'mouthStretchRight',
                'mouthRollLower', 'mouthRollUpper', 'mouthShrugLower', 'mouthShrugUpper',
                'mouthPressLeft', 'mouthPressRight', 'mouthLowerDownLeft', 'mouthLowerDownRight',
                'mouthUpperUpLeft', 'mouthUpperUpRight',

                // Character Creator variations
                'Mouth_Open', 'Mouth_Smile', 'Mouth_Wide', 'Mouth_Narrow',
                'Jaw_Open', 'Lips_Pucker', 'Lips_Funnel',

                // Viseme-like
                'viseme_aa', 'viseme_E', 'viseme_I', 'viseme_O', 'viseme_U',
                'V_Open', 'V_Explosive', 'V_Dental_Lip', 'V_Tight_O', 'V_Wide',
            ];

            // Test each mesh's morph targets
            for (const { mesh, morphs } of meshesWithMorphs) {
                setStatus(`Testing morphs on "${mesh.name}"...`);

                // Test common mouth shapes first
                for (const shapeName of ccMouthShapes) {
                    const morphIndex = mesh.morphTargetDictionary![shapeName];
                    if (morphIndex !== undefined && mesh.morphTargetInfluences) {
                        setStatus(`Testing: ${shapeName} ✓`);
                        console.log(`[VRMCompanion] Testing morph: "${shapeName}"`);

                        // Set morph value
                        mesh.morphTargetInfluences[morphIndex] = 1.0;
                        await new Promise(resolve => setTimeout(resolve, 600));

                        // Reset
                        mesh.morphTargetInfluences[morphIndex] = 0;
                        await new Promise(resolve => setTimeout(resolve, 200));
                    }
                }

                // Test ALL morph targets to see what they do
                setStatus(`Testing all ${morphs.length} morphs - watch closely!`);
                await new Promise(resolve => setTimeout(resolve, 1000));

                for (const morphName of morphs) {
                    setStatus(`Testing: "${morphName}"`);
                    console.log(`[VRMCompanion] Testing morph: "${morphName}"`);

                    const morphIndex = mesh.morphTargetDictionary![morphName];
                    if (morphIndex !== undefined && mesh.morphTargetInfluences) {
                        mesh.morphTargetInfluences[morphIndex] = 1.0;
                        await new Promise(resolve => setTimeout(resolve, 500));
                        mesh.morphTargetInfluences[morphIndex] = 0;
                        await new Promise(resolve => setTimeout(resolve, 200));
                    }
                }
            }

            setStatus('Done! Check console for all morph target names.');
            console.log('='.repeat(50));
            console.log('[VRMCompanion] FBX morph testing complete');
            console.log('='.repeat(50));
        } else {
            setStatus('⚠️ No model loaded or model has no blend shapes');
        }

        setIsTesting(false);
    }, [modelLoaded]);

    // Play a specific animation by index
    const playAnimation = useCallback((index: number) => {
        if (!mixerRef.current || !fbxModelRef.current) return;

        const model = vrmRef.current?.scene || fbxModelRef.current;
        if (!model) return;

        // Stop all current actions
        mixerRef.current.stopAllAction();

        // Get the animation clip
        const animations = (model as any).animations || (fbxModelRef.current as any).animations;
        if (!animations || index < 0 || index >= animations.length) return;

        // Play the selected animation
        const action = mixerRef.current.clipAction(animations[index]);
        action.reset();
        action.play();
        setCurrentAnimationIndex(index);
        setStatus(`Playing: ${availableAnimations[index]}`);
    }, [availableAnimations]);

    // Stop all animations
    const stopAnimation = useCallback(() => {
        if (!mixerRef.current) return;
        mixerRef.current.stopAllAction();
        setCurrentAnimationIndex(-1);
        setStatus('Animation stopped - idle pose');
    }, []);

    // Toggle mesh visibility
    const toggleMeshVisibility = useCallback((meshName: string) => {
        const meshItem = meshList.find(m => m.name === meshName);
        if (meshItem) {
            meshItem.mesh.visible = !meshItem.mesh.visible;
            setMeshList(prev => prev.map(m =>
                m.name === meshName ? { ...m, visible: m.mesh.visible } : m
            ));
        }
    }, [meshList]);

    return (
        <div className={`vrm-companion-container flex w-full h-full bg-black/40 backdrop-blur-md overflow-hidden border border-white/10 ${className}`}>
            {/* 3D Canvas - fills available space */}
            <div ref={containerRef} className="flex-1 relative h-full">
                <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm p-4 rounded-lg max-w-xs border border-cyan-500/30 pointer-events-none z-10">
                    <h1 className="text-lg font-bold mb-2 text-cyan-400">VRM Companion</h1>
                    <p className="text-sm text-gray-300">{status}</p>
                </div>
            </div>

            {/* Control Panel */}
            <div className="w-72 bg-black/60 p-4 overflow-y-auto border-l border-white/10">
                <h2 className="text-lg font-semibold mb-4 text-white">Controls</h2>

                {/* Model Selector */}
                {availableModels.length > 0 && (
                    <div className="mb-6">
                        <h3 className="text-md font-semibold mb-3 text-gray-400 uppercase tracking-wider text-xs">Model</h3>
                        <select
                            value={selectedModelUrl}
                            onChange={(e) => {
                                setSelectedModelUrl(e.target.value);
                                // Auto-reload when model changes
                                setTimeout(() => loadModel(), 100);
                            }}
                            className="w-full py-2 px-3 bg-black/60 border border-white/20 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500 mb-3"
                        >
                            <option value="">Select a model...</option>
                            {availableModels.map((model, i) => (
                                <option key={i} value={model.url}>{model.name}</option>
                            ))}
                        </select>
                    </div>
                )}

                {/* Action Buttons */}
                <div className="space-y-3 mb-6">
                    <button
                        onClick={loadVRM}
                        className="w-full py-2 px-4 bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-black font-bold rounded-lg transition-all shadow-[0_0_15px_rgba(0,255,153,0.3)] hover:shadow-[0_0_25px_rgba(0,255,153,0.5)]"
                    >
                        Reload Model
                    </button>

                    <button
                        onClick={playTTS}
                        disabled={!vrmLoaded || isPlaying}
                        className="w-full py-2 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition-all"
                    >
                        {isPlaying ? 'Speaking...' : 'Demo TTS'}
                    </button>

                    <button
                        onClick={toggleMic}
                        disabled={!vrmLoaded}
                        className={`w-full py-2 px-4 rounded-lg font-semibold transition-all ${isMicActive
                            ? 'bg-red-600 hover:bg-red-500 text-white'
                            : 'bg-purple-600 hover:bg-purple-500 text-white'
                            } disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed`}
                    >
                        {isMicActive ? '🔴 Stop Mic' : '🎤 Start Mic'}
                    </button>

                    <button
                        onClick={testExpressions}
                        disabled={!modelLoaded || isTesting}
                        className="w-full py-2 px-4 bg-amber-600 hover:bg-amber-500 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition-all"
                    >
                        {isTesting ? 'Testing...' : '🎭 Test Expressions'}
                    </button>
                </div>

                {/* Toggles */}
                <div className="mb-6 space-y-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                        <input
                            type="checkbox"
                            checked={amplitudeMode}
                            onChange={(e) => setAmplitudeMode(e.target.checked)}
                            className="w-4 h-4 accent-cyan-500"
                        />
                        <span className="text-sm text-gray-300">Amplitude-only mode</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                        <input
                            type="checkbox"
                            checked={physicsEnabled}
                            onChange={(e) => setPhysicsEnabled(e.target.checked)}
                            className="w-4 h-4 accent-cyan-500"
                        />
                        <span className="text-sm text-gray-300">Enable physics (hair/cloth)</span>
                    </label>
                </div>

                {/* Animation Controls */}
                {availableAnimations.length > 0 && (
                    <div className="mb-6">
                        <h3 className="text-md font-semibold mb-3 text-gray-400 uppercase tracking-wider text-xs">
                            Animations ({availableAnimations.length})
                        </h3>
                        <div className="space-y-2">
                            <select
                                value={currentAnimationIndex}
                                onChange={(e) => {
                                    const idx = parseInt(e.target.value);
                                    if (idx >= 0) {
                                        playAnimation(idx);
                                    }
                                }}
                                className="w-full py-2 px-3 bg-black/60 border border-white/20 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500"
                            >
                                <option value={-1}>Select animation...</option>
                                {availableAnimations.map((name, i) => (
                                    <option key={i} value={i}>{name}</option>
                                ))}
                            </select>

                            <button
                                onClick={stopAnimation}
                                disabled={currentAnimationIndex === -1}
                                className="w-full py-2 px-4 bg-red-600 hover:bg-red-500 disabled:bg-gray-700 disabled:text-gray-500 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition-all text-sm"
                            >
                                ⏹️ Stop Animation
                            </button>
                        </div>
                    </div>
                )}

                {/* Config Sliders */}
                <h3 className="text-md font-semibold mb-3 text-gray-400 uppercase tracking-wider text-xs">Config</h3>
                <div className="space-y-4 mb-6">
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">
                            Smoothing: {smoothing.toFixed(2)}
                        </label>
                        <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.01"
                            value={smoothing}
                            onChange={(e) => setSmoothing(parseFloat(e.target.value))}
                            className="w-full accent-cyan-500"
                        />
                    </div>

                    <div>
                        <label className="text-sm text-gray-400 block mb-1">
                            Gain: {gain.toFixed(2)}
                        </label>
                        <input
                            type="range"
                            min="0.5"
                            max="5"
                            step="0.1"
                            value={gain}
                            onChange={(e) => setGain(parseFloat(e.target.value))}
                            className="w-full accent-cyan-500"
                        />
                    </div>

                    <div>
                        <label className="text-sm text-gray-400 block mb-1">
                            Max Mouth Open: {maxMouthOpen.toFixed(2)}
                        </label>
                        <input
                            type="range"
                            min="0.1"
                            max="1"
                            step="0.01"
                            value={maxMouthOpen}
                            onChange={(e) => setMaxMouthOpen(parseFloat(e.target.value))}
                            className="w-full accent-cyan-500"
                        />
                    </div>
                </div>

                {/* Viseme Weights Display */}
                <h3 className="text-md font-semibold mb-3 text-gray-400 uppercase tracking-wider text-xs">Viseme Weights</h3>
                <div className="space-y-2 bg-black/40 p-3 rounded-lg font-mono text-sm border border-white/5 mb-6">
                    {Object.entries(visemeWeights).map(([key, value]) => (
                        <div key={key} className="flex items-center gap-2">
                            <span className="w-8 text-gray-500">{key}:</span>
                            <div className="flex-1 bg-gray-800 rounded-full h-2 overflow-hidden">
                                <div
                                    className="h-full bg-gradient-to-r from-cyan-500 to-emerald-500 transition-all duration-75"
                                    style={{ width: `${value * 100}%` }}
                                />
                            </div>
                            <span className="w-14 text-right text-gray-500 text-xs">
                                {value.toFixed(3)}
                            </span>
                        </div>
                    ))}
                </div>

                {/* Available Expressions from VRM Metadata */}
                {availableExpressions.length > 0 && (
                    <>
                        <h3 className="text-md font-semibold mb-3 text-gray-400 uppercase tracking-wider text-xs">
                            Model Expressions ({availableExpressions.length})
                        </h3>
                        <div className="bg-black/40 p-3 rounded-lg font-mono text-xs border border-white/5 max-h-48 overflow-y-auto">
                            {availableExpressions.map((expr, i) => {
                                // Highlight mouth-related expressions
                                const isMouth = /mouth|mth|lip|jaw|smile|frown|open|close|vowel|viseme|^[AIUEO]$/i.test(expr);
                                const isViseme = ['aa', 'ih', 'ou', 'ee', 'oh'].includes(expr);
                                return (
                                    <div
                                        key={i}
                                        className={`py-0.5 ${isViseme ? 'text-emerald-400 font-bold' : isMouth ? 'text-cyan-400' : 'text-gray-500'}`}
                                    >
                                        {expr} {isViseme && '✓'} {isMouth && !isViseme && '○'}
                                    </div>
                                );
                            })}
                        </div>
                    </>
                )}

                {/* Mesh Visibility Controls - FBX only */}
                {meshList.length > 0 && (
                    <>
                        <h3 className="text-md font-semibold mb-3 text-gray-400 uppercase tracking-wider text-xs">
                            Mesh Visibility ({meshList.length})
                        </h3>
                        <div className="bg-black/40 p-3 rounded-lg font-mono text-xs border border-white/5 max-h-64 overflow-y-auto mb-6">
                            {meshList.map((meshItem, i) => (
                                <label key={i} className="flex items-center gap-2 py-1 cursor-pointer hover:bg-white/5 rounded px-1">
                                    <input
                                        type="checkbox"
                                        checked={meshItem.visible}
                                        onChange={() => toggleMeshVisibility(meshItem.name)}
                                        className="w-3 h-3 accent-cyan-500"
                                    />
                                    <span className={meshItem.visible ? 'text-gray-300' : 'text-gray-600 line-through'}>
                                        {meshItem.name}
                                    </span>
                                </label>
                            ))}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default VRMCompanion;
