"""
VRM Companion Backend Routes

Provides status and optional phoneme generation endpoints.
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from typing import Dict, Any, List
from pathlib import Path
import os
import mimetypes

router = APIRouter()

# Static file serving for model assets
assets_dir = Path(__file__).parent.parent / "assets"
models_dir = assets_dir / "models"


@router.get("/assets/models/{file_path:path}")
async def serve_model(file_path: str):
    """
    Serve model files (.vrm, .fbx, .glb) with proper MIME types.
    FastAPI route handler for static assets since we can't mount StaticFiles in a router.
    """
    full_path = models_dir / file_path
    
    if not full_path.exists() or not full_path.is_file():
        raise HTTPException(status_code=404, detail=f"Model file not found: {file_path}")
    
    # Detect MIME type
    content_type, _ = mimetypes.guess_type(str(full_path))
    if not content_type:
        # Default to binary for .vrm, .fbx, .glb files
        ext = full_path.suffix.lower()
        if ext in ['.vrm', '.glb']:
            content_type = 'model/gltf-binary'
        elif ext == '.fbx':
            content_type = 'application/octet-stream'
        else:
            content_type = 'application/octet-stream'
    
    return FileResponse(
        path=str(full_path),
        media_type=content_type,
        filename=full_path.name
    )


@router.get("/status")
async def get_status():
    """
    Health check endpoint: /marketplace/modules/vrm-companion/status
    """
    return {
        "status": "online",
        "module": "vrm-companion",
        "version": "1.0.0"
    }

@router.get("/models")
async def list_models():
    """
    List all available 3D models (VRM, FBX, GLB) organized in subdirectories.
    Returns absolute URLs that frontend can fetch directly.
    """
    models_base = Path(__file__).parent.parent / "assets" / "models"
    
    models = []
    
    # Scan VRoid folder (VRoid Studio exports - VRM format)
    vroid_dir = models_base / "VRoid"
    if vroid_dir.exists():
        for file in vroid_dir.rglob("*.vrm"):
            rel_path = file.relative_to(models_base)
            models.append({
                "name": f"{file.stem.replace('_', ' ').title()} (VRoid)",
                "url": f"/marketplace/modules/vrm-companion/assets/models/{rel_path.as_posix()}",
                "type": "vrm"
            })

    # Scan Reallusion folder (Character Creator exports - FBX format)
    reallusion_dir = models_base / "Reallusion"
    if reallusion_dir.exists():
        for file in reallusion_dir.rglob("*.fbx"):
            rel_path = file.relative_to(models_base)
            # Use parent folder name for model name (test2, test3, etc.)
            model_name = file.parent.name if file.parent.name != "Reallusion" else file.stem
            models.append({
                "name": f"{model_name.replace('_', ' ').title()} (Reallusion/CC)",
                "url": f"/marketplace/modules/vrm-companion/assets/models/{rel_path.as_posix()}",
                "type": "fbx"
            })

    # Scan UnrealEngine folder (UE exports - FBX format)
    ue_dir = models_base / "UnrealEngine"
    if ue_dir.exists():
        for file in ue_dir.rglob("*.fbx"):
            rel_path = file.relative_to(models_base)
            model_name = file.parent.name if file.parent.name != "UnrealEngine" else file.stem
            models.append({
                "name": f"{model_name.replace('_', ' ').title()} (Unreal Engine)",
                "url": f"/marketplace/modules/vrm-companion/assets/models/{rel_path.as_posix()}",
                "type": "fbx"
            })

    # Scan MetaHuman folder (MetaHuman exports)
    metahuman_dir = models_base / "MetaHuman"
    if metahuman_dir.exists():
        for file in metahuman_dir.rglob("*.fbx"):
            rel_path = file.relative_to(models_base)
            model_name = file.parent.name if file.parent.name != "MetaHuman" else file.stem
            models.append({
                "name": f"{model_name.replace('_', ' ').title()} (MetaHuman)",
                "url": f"/marketplace/modules/vrm-companion/assets/models/{rel_path.as_posix()}",
                "type": "fbx"
            })
    
    # Scan for GLB/GLTF files in root models dir
    for ext in ["*.glb", "*.gltf"]:
        for file in models_base.rglob(ext):
            rel_path = file.relative_to(models_base)
            models.append({
                "name": f"{file.stem.replace('_', ' ').title()} (GLB)",
                "url": f"/marketplace/modules/vrm-companion/assets/models/{rel_path.as_posix()}",
                "type": "glb"
            })
    
    return models

@router.post("/phonemes")
async def generate_phonemes(data: Dict[str, Any]):
    """
    Generate phonemes from text using the main backend's phonemizer.
    Proxies to /tts/phonemes which uses the phonemizer library.
    """
    text = data.get("text", "")
    if not text:
        return {
            "text": "",
            "phonemes": "",
            "message": "No text provided"
        }
    
    try:
        # Call the main backend's phonemizer endpoint
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "http://127.0.0.1:8001/tts/phonemes",
                json={"text": text},
                timeout=5.0
            )
            
            if response.status_code == 200:
                result = response.json()
                # Main backend returns {"phonemes": "..."}
                return {
                    "text": text,
                    "phonemes": result.get("phonemes", ""),
                    "message": "Phonemes generated successfully"
                }
            else:
                # Fallback if main backend unavailable
                return {
                    "text": text,
                    "phonemes": "",
                    "message": f"Phonemizer unavailable (status {response.status_code})"
                }
    except Exception as e:
        # Graceful fallback - return empty phonemes
        return {
            "text": text,
            "phonemes": "",
            "message": f"Phoneme generation failed: {str(e)}"
        }
