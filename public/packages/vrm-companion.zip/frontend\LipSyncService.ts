import { VRM } from '@pixiv/three-vrm';
import * as THREE from 'three';

export type VisemeKey = 'aa' | 'ih' | 'ou' | 'ee' | 'oh';

// FBX/Character Creator morph target info
export type FBXMorphTarget = {
    mesh: THREE.Mesh;
    morphIndex: number;
    morphName: string;
};

export type PhonemeEvent = {
    t0: number;
    t1: number;
    phoneme: string;
    stress?: number;
};

export type LipSyncConfig = {
    smoothing?: number;
    gain?: number;
    maxMouthOpen?: number;
    phonemeMap?: Partial<Record<string, VisemeKey>>;
};

// Kokoro/Misaki IPA phoneme → VRM viseme mapping
// VRM visemes: aa (open), ih (front close), ou (rounded), ee (mid), oh (back rounded)
//
// Misaki phoneme set (49 phonemes):
// Consonants: b, d, f, h, j, k, l, m, n, p, s, t, v, w, z, ɡ, ŋ, ɹ, ʃ, ʒ, ð, θ, ʤ, tʃ
// Vowels: ə, i, u, ɑ, ɔ, ɛ, ɜ, ɪ, ʊ, ʌ
// Diphthongs: A (eɪ), I (aɪ), W (aʊ), Y (ɔɪ)
const DEFAULT_PHONEME_MAP: Record<string, VisemeKey> = {
    // === VOWELS (IPA from Kokoro/Misaki) ===
    'ɑ': 'aa',   // spa - wide open
    'ɔ': 'oh',   // all - rounded back
    'ɛ': 'ee',   // bed, hair - mid
    'ɜ': 'ee',   // her - mid
    'ɪ': 'ih',   // brick - front close
    'ʊ': 'ou',   // wood - rounded
    'ʌ': 'aa',   // sun - open
    'ə': 'aa',   // schwa - neutral/open
    'i': 'ih',   // easy - front close
    'u': 'ou',   // flu - rounded

    // === DIPHTHONGS (Misaki uses capital letters) ===
    'A': 'ee',   // hey (eɪ) - ends front
    'I': 'aa',   // high (aɪ) - starts open
    'W': 'aa',   // how (aʊ) - starts open
    'Y': 'oh',   // soy (ɔɪ) - starts rounded

    // === CONSONANTS with mouth shape ===
    // Bilabials (lips together then open)
    'b': 'aa', 'p': 'aa', 'm': 'aa',
    // Labiodentals (teeth on lip)
    'f': 'ih', 'v': 'ih',
    // Dentals (tongue on teeth)
    'θ': 'ee', 'ð': 'ee',
    // Alveolars
    't': 'aa', 'd': 'aa', 'n': 'aa', 's': 'ih', 'z': 'ih', 'l': 'aa',
    // Post-alveolars
    'ʃ': 'ih', 'ʒ': 'ih', 'tʃ': 'ih', 'ʤ': 'ih',
    // Palatal
    'j': 'ih',
    // Velars
    'k': 'oh', 'ɡ': 'oh', 'ŋ': 'oh',
    // Glottal
    'h': 'aa',
    // Approximants
    'ɹ': 'aa', 'w': 'ou',

    // === ARPAbet fallback (for g2p_en output) ===
    'AA': 'aa', 'AE': 'aa', 'AH': 'aa', 'AO': 'oh', 'AW': 'aa', 'AY': 'aa',
    'IY': 'ih', 'IH': 'ih', 'EY': 'ee',
    'UW': 'ou', 'UH': 'ou', 'OW': 'oh',
    'EH': 'ee', 'ER': 'ee',
    'OY': 'oh',
    'B': 'aa', 'P': 'aa', 'M': 'aa',
    'F': 'ih', 'V': 'ih',
    'TH': 'ee', 'DH': 'ee',
    'S': 'ih', 'Z': 'ih', 'SH': 'ih', 'ZH': 'ih', 'CH': 'ih', 'JH': 'ih',
    'N': 'aa', 'L': 'aa', 'R': 'aa', 'T': 'aa', 'D': 'aa',
    'K': 'oh', 'G': 'oh', 'NG': 'oh',
    'HH': 'aa',
    // Note: 'W' and 'Y' defined above as Misaki diphthongs
};

// Character Creator / ARKit blend shape → viseme mapping
// These are common blend shapes from Character Creator exports
const CC_MORPH_TO_VISEME: Record<string, VisemeKey> = {
    // ARKit-style visemes (from CC4 ARKit profile)
    'jawOpen': 'aa',
    'mouthOpen': 'aa',
    'Jaw_Open': 'aa',
    'V_Open': 'aa',

    // Lip shapes that map to visemes
    'mouthFunnel': 'ou',     // Rounded O
    'mouthPucker': 'ou',     // Pursed lips
    'Mouth_Pucker': 'ou',
    'V_Tight_O': 'ou',
    'V_Tight': 'ou',

    'mouthSmileLeft': 'ee',
    'mouthSmileRight': 'ee',
    'Mouth_Smile': 'ee',
    'V_Wide': 'ee',

    'mouthFrownLeft': 'oh',
    'mouthFrownRight': 'oh',

    // Viseme-specific (Oculus/Meta lipsync style)
    'viseme_aa': 'aa',
    'viseme_E': 'ee',
    'viseme_I': 'ih',
    'viseme_O': 'oh',
    'viseme_U': 'ou',
    'viseme_PP': 'aa',   // Bilabial plosive
    'viseme_FF': 'ih',   // Labiodental
    'viseme_TH': 'ee',   // Dental
    'viseme_DD': 'aa',   // Alveolar
    'viseme_kk': 'oh',   // Velar
    'viseme_CH': 'ih',   // Postalveolar
    'viseme_SS': 'ih',   // Sibilant
    'viseme_nn': 'aa',   // Nasal
    'viseme_RR': 'aa',   // Approximant
    'viseme_sil': 'aa',  // Silence (neutral)

    // CC ExPlus / iClone style
    'Mouth_Open': 'aa',
    'Mouth_Wide': 'ee',
    'Mouth_Narrow': 'ou',
    'Mouth_Up': 'oh',
    'Mouth_Down': 'aa',
    'Mouth_L': 'ee',
    'Mouth_R': 'ee',

    // A/E/I/O/U direct (some CC exports)
    'A': 'aa',
    'E': 'ee',
    'I': 'ih',
    'O': 'oh',
    'U': 'ou',
};

export class LipSyncService {
    private vrm: VRM | null = null;
    private fbxModel: THREE.Group | null = null;
    private fbxMorphTargets: Map<VisemeKey, FBXMorphTarget[]> = new Map();
    private audio: HTMLAudioElement | null = null;
    private analyser: AnalyserNode | null = null;
    private audioContext: AudioContext | null = null;
    private dataArray: Uint8Array | null = null;
    private mediaSource: MediaElementAudioSourceNode | null = null;
    private micStream: MediaStream | null = null;
    private micSource: MediaStreamAudioSourceNode | null = null;

    private timeline: PhonemeEvent[] = [];
    private _currentWeights: Record<VisemeKey, number> = { aa: 0, ih: 0, ou: 0, ee: 0, oh: 0 };
    private targetWeights: Record<VisemeKey, number> = { aa: 0, ih: 0, ou: 0, ee: 0, oh: 0 };

    private config: Required<LipSyncConfig>;
    private phonemeMap: Record<string, VisemeKey>;
    private hasVisemes = false;
    private isFBXMode = false;
    public amplitudeOnly = false;
    public forceAmplitudeMode = false;
    private isMicMode = false;

    constructor(config: LipSyncConfig = {}) {
        this.config = {
            smoothing: config.smoothing ?? 0.3,
            gain: config.gain ?? 2.0,
            maxMouthOpen: config.maxMouthOpen ?? 0.8,
            phonemeMap: config.phonemeMap ?? {},
        };
        this.phonemeMap = { ...DEFAULT_PHONEME_MAP, ...this.config.phonemeMap };
    }

    get currentWeights(): Record<VisemeKey, number> {
        return { ...this._currentWeights };
    }

    updateConfig(config: Partial<LipSyncConfig>): void {
        if (config.smoothing !== undefined) this.config.smoothing = config.smoothing;
        if (config.gain !== undefined) this.config.gain = config.gain;
        if (config.maxMouthOpen !== undefined) this.config.maxMouthOpen = config.maxMouthOpen;
    }

    connectToAvatar(vrm: VRM): void {
        this.vrm = vrm;
        this.fbxModel = null;
        this.isFBXMode = false;

        if (!vrm.expressionManager) {
            console.warn('[LipSync] VRM expressionManager not found, amplitude-only mode');
            this.amplitudeOnly = true;
            return;
        }

        const expressions = vrm.expressionManager.expressions || [];
        const visemeNames: VisemeKey[] = ['aa', 'ih', 'ou', 'ee', 'oh'];
        this.hasVisemes = visemeNames.some(v =>
            expressions.some((e: { expressionName?: string; name?: string }) =>
                e.expressionName === v || e.name === v)
        );

        if (!this.hasVisemes) {
            console.warn('[LipSync] VRM missing viseme blendshapes, amplitude-only mode');
            this.amplitudeOnly = true;
        }
    }

    connectToFBX(model: THREE.Group): void {
        this.fbxModel = model;
        this.vrm = null;
        this.isFBXMode = true;
        this.fbxMorphTargets.clear();

        // Scan all meshes for morph targets and map them to visemes
        const foundMorphs: string[] = [];

        model.traverse((child) => {
            const mesh = child as THREE.Mesh;
            if (!mesh.isMesh || !mesh.morphTargetDictionary || !mesh.morphTargetInfluences) {
                return;
            }

            for (const [morphName, morphIndex] of Object.entries(mesh.morphTargetDictionary)) {
                // Check if this morph maps to a viseme
                const viseme = CC_MORPH_TO_VISEME[morphName];
                if (viseme) {
                    if (!this.fbxMorphTargets.has(viseme)) {
                        this.fbxMorphTargets.set(viseme, []);
                    }
                    this.fbxMorphTargets.get(viseme)!.push({
                        mesh,
                        morphIndex,
                        morphName,
                    });
                    foundMorphs.push(`${morphName} → ${viseme}`);
                }
            }
        });

        if (foundMorphs.length > 0) {
            console.log('[LipSync] FBX morph targets mapped:', foundMorphs);
            this.hasVisemes = true;
            this.amplitudeOnly = false;
        } else {
            console.warn('[LipSync] No mouth morphs found on FBX, using amplitude-only mode');
            // Try to find ANY morph target for amplitude mode (use jawOpen equivalent)
            model.traverse((child) => {
                const mesh = child as THREE.Mesh;
                if (!mesh.isMesh || !mesh.morphTargetDictionary || !mesh.morphTargetInfluences) {
                    return;
                }
                // Look for any jaw/mouth morph for amplitude-only fallback
                for (const [morphName, morphIndex] of Object.entries(mesh.morphTargetDictionary)) {
                    const lowerName = morphName.toLowerCase();
                    if (lowerName.includes('jaw') || lowerName.includes('mouth') || lowerName.includes('open')) {
                        if (!this.fbxMorphTargets.has('aa')) {
                            this.fbxMorphTargets.set('aa', []);
                        }
                        this.fbxMorphTargets.get('aa')!.push({
                            mesh,
                            morphIndex,
                            morphName,
                        });
                        console.log(`[LipSync] FBX fallback morph: ${morphName} → aa`);
                        this.hasVisemes = true;
                        return;
                    }
                }
            });

            if (!this.hasVisemes) {
                this.amplitudeOnly = true;
            }
        }
    }

    async connectToAudio(audio: HTMLAudioElement, externalAnalyser?: AnalyserNode): Promise<void> {
        this.audio = audio;
        this.isMicMode = false;

        // If external analyser provided (from shared ttsService), use it directly
        if (externalAnalyser) {
            this.analyser = externalAnalyser;
            this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
            console.log('[LipSync] Using external analyser from ttsService');
            return;
        }

        // Try to create our own analyser (may fail if audio already connected)
        try {
            if (!this.audioContext) {
                this.audioContext = new AudioContext();
            }

            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }

            if (!this.mediaSource) {
                this.mediaSource = this.audioContext.createMediaElementSource(audio);
            }

            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 256;
            this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);

            this.mediaSource.connect(this.analyser);
            this.analyser.connect(this.audioContext.destination);
        } catch (_err) {
            // Audio already connected to another source - fall back to forceAmplitudeMode
            console.warn('[LipSync] Audio already connected, using amplitude from ttsService');
            this.forceAmplitudeMode = true;
        }
    }

    async connectToMic(): Promise<void> {
        this.isMicMode = true;

        if (!this.audioContext) {
            this.audioContext = new AudioContext();
        }

        if (this.audioContext.state === 'suspended') {
            await this.audioContext.resume();
        }

        this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        this.micSource = this.audioContext.createMediaStreamSource(this.micStream);

        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 256;
        this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);

        this.micSource.connect(this.analyser);
    }

    disconnectMic(): void {
        if (this.micStream) {
            this.micStream.getTracks().forEach(track => track.stop());
            this.micStream = null;
        }
        if (this.micSource) {
            this.micSource.disconnect();
            this.micSource = null;
        }
        this.isMicMode = false;
    }

    ingestPhonemeTimeline(timeline: PhonemeEvent[]): void {
        this.timeline = [...timeline].sort((a, b) => a.t0 - b.t0);
    }

    update(dt: number): void {
        // Need either VRM or FBX model
        if (!this.vrm && !this.fbxModel) {
            console.warn('[LipSync] update() called but no model connected');
            return;
        }

        if (this.isMicMode) {
            this.targetWeights = { aa: 0, ih: 0, ou: 0, ee: 0, oh: 0 };
            this.updateFromAmplitude();
            this.smoothWeights(dt);
            this.applyWeights();
            return;
        }

        if (!this.audio) {
            console.warn('[LipSync] update() called but no audio element');
            return;
        }

        const currentTime = this.audio.currentTime;
        const isPlaying = !this.audio.paused && !this.audio.ended;

        if (!isPlaying) {
            this.decayAllWeights(dt);
            this.applyWeights();
            return;
        }

        this.targetWeights = { aa: 0, ih: 0, ou: 0, ee: 0, oh: 0 };

        // Log mode selection
        const usePhonemes = this.timeline.length > 0 && !this.amplitudeOnly && !this.forceAmplitudeMode;
        if (currentTime < 0.1) { // Only log at start to avoid spam
            console.log('[LipSync] Update mode:', {
                usePhonemes,
                timelineLength: this.timeline.length,
                amplitudeOnly: this.amplitudeOnly,
                forceAmplitudeMode: this.forceAmplitudeMode,
                currentTime,
                hasAnalyser: !!this.analyser
            });
        }

        if (usePhonemes) {
            this.updateFromPhonemes(currentTime);
        } else {
            this.updateFromAmplitude();
        }

        this.smoothWeights(dt);
        this.applyWeights();
    }

    private updateFromPhonemes(currentTime: number): void {
        let foundMatch = false;
        for (const event of this.timeline) {
            if (currentTime >= event.t0 && currentTime <= event.t1) {
                const viseme = this.phonemeMap[event.phoneme];
                if (viseme) {
                    const progress = (currentTime - event.t0) / (event.t1 - event.t0);
                    const envelope = Math.sin(progress * Math.PI);
                    const weight = envelope * (event.stress ?? 1) * this.config.gain;
                    this.targetWeights[viseme] = Math.min(weight, this.config.maxMouthOpen);

                    if (!foundMatch) {
                        console.log('[LipSync] Phoneme match:', {
                            time: currentTime.toFixed(3),
                            phoneme: event.phoneme,
                            viseme,
                            weight: weight.toFixed(3),
                            envelope: envelope.toFixed(3)
                        });
                        foundMatch = true;
                    }
                } else {
                    console.warn('[LipSync] Unmapped phoneme:', event.phoneme);
                }
            }
        }
        if (!foundMatch && currentTime < 0.5) {
            console.warn('[LipSync] No phoneme match at time:', currentTime.toFixed(3), 'timeline length:', this.timeline.length);
        }
    }

    private updateFromAmplitude(): void {
        if (!this.analyser || !this.dataArray) return;

        this.analyser.getByteFrequencyData(this.dataArray as Uint8Array<ArrayBuffer>);

        let sum = 0;
        for (let i = 0; i < this.dataArray.length; i++) {
            sum += this.dataArray[i] * this.dataArray[i];
        }
        const rms = Math.sqrt(sum / this.dataArray.length) / 255;
        const amplitude = Math.min(rms * this.config.gain, this.config.maxMouthOpen);

        if (amplitude > 0.01) {
            console.log('[LipSync] Amplitude calculated:', amplitude, 'RMS:', rms);
        }
        this.targetWeights.aa = amplitude;
    }

    private smoothWeights(dt: number): void {
        const factor = 1 - Math.pow(this.config.smoothing, dt * 60);
        for (const key of Object.keys(this._currentWeights) as VisemeKey[]) {
            this._currentWeights[key] += (this.targetWeights[key] - this._currentWeights[key]) * factor;
        }
    }

    private decayAllWeights(dt: number): void {
        const decayRate = 1 - Math.pow(0.1, dt * 60);
        for (const key of Object.keys(this._currentWeights) as VisemeKey[]) {
            this._currentWeights[key] *= (1 - decayRate);
        }
    }

    private applyWeights(): void {
        const nonZeroWeights = Object.entries(this._currentWeights).filter(([_, w]) => w > 0.01);

        if (this.isFBXMode && this.fbxModel) {
            // Apply weights to FBX morph targets
            let appliedCount = 0;
            for (const [viseme, weight] of Object.entries(this._currentWeights) as [VisemeKey, number][]) {
                const targets = this.fbxMorphTargets.get(viseme);
                if (targets) {
                    const clampedWeight = Math.max(0, Math.min(1, weight));
                    for (const target of targets) {
                        if (target.mesh.morphTargetInfluences) {
                            target.mesh.morphTargetInfluences[target.morphIndex] = clampedWeight;
                            appliedCount++;
                        }
                    }
                }
            }
            if (nonZeroWeights.length > 0) {
                console.log('[LipSync] Applied FBX weights:', { nonZeroWeights, appliedCount });
            }
            return;
        }

        // VRM mode
        if (!this.vrm?.expressionManager) {
            console.warn('[LipSync] No VRM expressionManager to apply weights to');
            return;
        }

        // VRM has: aa, ee, ih, oh, ou - use directly
        for (const [viseme, weight] of Object.entries(this._currentWeights)) {
            const clampedWeight = Math.max(0, Math.min(1, weight));
            this.vrm.expressionManager.setValue(viseme, clampedWeight);
        }

        if (nonZeroWeights.length > 0) {
            console.log('[LipSync] Applied VRM weights:', nonZeroWeights);
        }

        // Force update the expression manager (required for some VRM models)
        this.vrm.expressionManager.update();
    }

    dispose(): void {
        this.disconnectMic();
        this.vrm = null;
        this.fbxModel = null;
        this.fbxMorphTargets.clear();
        this.isFBXMode = false;
        this.audio = null;
        this.timeline = [];

        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
        this.analyser = null;
        this.dataArray = null;
        this.mediaSource = null;
    }
}

export default LipSyncService;
