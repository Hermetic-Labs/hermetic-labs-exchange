/**
 * iot-connector - EVE OS Marketplace Package
 */

// IoT Services Barrel Export
export * from './IoTDeviceAdapter';
export { IoTTemplateEngine } from './IoTTemplateEngine';
export type { TemplateMetadata, TemplateVariable, TemplateCategory } from './IoTTemplateEngine';
export { default as IoTWorkflowEngine } from './IoTWorkflowEngine';
export { deviceDiscovery } from './DeviceDiscovery';
export * from './DeviceProtocols';
export * from './DeviceSafety';
export { DevicePairingService } from './DevicePairingService';

// Type exports
export * from './types';
