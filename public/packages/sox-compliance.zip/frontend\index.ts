﻿/**
 * SOX Compliance Suite - EVE OS Marketplace Package
 * @packageDocumentation
 */

// Main service class
export * from './SOXComplianceService';

// Types
export type {
    SOXConfig,
    ControlType,
    ControlFrequency,
    TestResult,
    DeficiencySeverity,
    ControlStatus,
    ControlParams,
    Control,
    ControlListResult,
    ControlTestParams,
    ControlTestResult,
    SODCheckParams,
    SODConflict,
    SODCheckResult,
    DeficiencyParams,
    DeficiencyResult,
    AuditTrailEntry,
    AuditTrailResult,
    SOXEventMap
} from './types';
