export { useDataAdapter, useMultipleAdapters } from './useDataAdapter';
