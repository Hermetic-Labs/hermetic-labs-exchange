﻿/**
 * FHIR Compliance Suite - EVE OS Marketplace Package
 * @packageDocumentation
 */

// Main service class
export * from './FHIRComplianceService';

// Types
export type {
    FHIRConfig,
    FHIRResourceType,
    HumanName,
    ContactPoint,
    Address,
    Identifier,
    Reference,
    CodeableConcept,
    Gender,
    ValidationParams,
    ValidationIssue,
    ValidationResult,
    PatientParams,
    Patient,
    ObservationParams,
    Observation,
    SearchParams,
    BundleEntry,
    SearchResult,
    FHIREventMap
} from './types';
